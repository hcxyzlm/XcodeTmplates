//___FILEHEADER___

import UIKit
import RxCocoa
import RxSwift
import Action

/// <#Description#>
class ___FILEBASENAMEASIDENTIFIER___: BaseViewModel {
    // MARK: - Public
    
    // MARK: - private
}

// MARK: - Public Methods
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - Private Methods 
private extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
