//___FILEHEADER___

import UIKit
import TangramKit
import RxCocoa
import RxSwift
import Action

/// <#Description#>
class ___FILEBASENAMEASIDENTIFIER___: BaseViewController {
    
    // MARK: - Accessor
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        bindViewModel()
        // Do any additional setup after loading the view.
    }
}

// MARK: - Public Methods
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - Private Methods
private extension ___FILEBASENAMEASIDENTIFIER___ {
    func setupUI() {
        
    }
    
    func bindViewModel() {
        
    }
}

// MARK: - Event
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - Delegate
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
